package Controller;

import javafx.fxml.FXML;

public class ResetPassword {

    @FXML
    private void handleReset() {
        Navigation.navigateTo("/View/VerificationPage.fxml", "Verification Page");
    }

    @FXML
    private void handleBackToLogin() {
        Navigation.navigateTo("/View/LoginPage.fxml", "Login Page");
    }
    
}
