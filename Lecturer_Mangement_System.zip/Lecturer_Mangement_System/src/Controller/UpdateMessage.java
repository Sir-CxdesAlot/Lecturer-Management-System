package Controller;

import javafx.fxml.FXML;

public class UpdateMessage {

    @FXML
    private void handleReturn() {
        Navigation.navigateTo("/View/FacultyLecturers.fxml", "Return to Faculty Lecturers");
    }
    
}
