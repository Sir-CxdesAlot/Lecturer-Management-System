package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class LoginPage {

    @FXML
    private void handleLogin() {
        Navigation.navigateTo("/View/FacultyLecturers.fxml", "Faculty Lecturers");
    }

    @FXML
    private void handleForgotPassword(ActionEvent event) {
        Navigation.navigateTo("/View/ResetPassword.fxml", "Reset Password");
    }
}
