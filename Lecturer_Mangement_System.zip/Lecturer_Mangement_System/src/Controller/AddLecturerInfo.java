package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class AddLecturerInfo {

    @FXML
    private void handleSubmit(ActionEvent event) {
        Navigation.navigateTo("/View/AddLecturerConfirmation.fxml", "Confirmation");
    }

    @FXML
    private void handleAddCourse(ActionEvent event) {
        Navigation.navigateTo("/View/CourseCatalog.fxml", "Add Course");
    }
}
