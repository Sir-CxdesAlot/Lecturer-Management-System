package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class AddCourseInfo {

    @FXML
    private void handleAddCourse(ActionEvent event) {
        Navigation.navigateTo("/View/CourseCatalog.fxml", "Course Catalog");
    }
}
