package Controller;

import javafx.fxml.FXML;

public class DeletionMessage {
    
    @FXML
    private void handleReturnHome() {
        Navigation.navigateTo("/View/FacultyLecturers.fxml", "Return Home");
    }
}
