package Controller;
import Model.CourseCardModel;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class CourseCatalog2 {
    
    @FXML
    private Label CourseTitle;

    @FXML
    private Label LecturerTitle;

    @FXML
    private Label CourseInfo;

    private CourseCardModel CourseCard;

    // Populate individual card with data
    public void setCourse(CourseCardModel CourseCard) {
        this.CourseCard = CourseCard;

        // Setting the cards properties using the model's getters
        CourseTitle.setText(CourseCard.getCourseTitle());
        LecturerTitle.setText(CourseCard.getLecturerTitle());
        CourseInfo.setText(CourseCard.getCourseInfo());
    }

    @FXML
    private void handleEnroll() {
        // Logic to handle enrollment can be added here
       Navigation.navigateTo("/View/AddLecturerInfo.fxml", "AddLecturerInfo");
    }
}