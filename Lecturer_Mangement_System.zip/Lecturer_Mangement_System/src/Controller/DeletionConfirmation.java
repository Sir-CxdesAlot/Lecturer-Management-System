package Controller;

import javafx.fxml.FXML;

public class DeletionConfirmation {

    @FXML
    private void handleDeletionConfirmation() {
        Navigation.navigateTo("/View/DeletionMessage.fxml", "Deletion Message");
    }
    
}
