package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class AddLecturerConfirmation {

    @FXML
    private void handleBackToFaculty(ActionEvent event) {
        // Navigate back to FacultyLecturers.fxml
        Navigation.navigateTo("/View/FacultyLecturers.fxml", "Faculty Lecturers");
    }
    
    @FXML
    private void handleAddAnotherLecturer() {
    Navigation.navigateTo("/View/AddLecturerInfo.fxml", "Add Lecturer");
    }

}
