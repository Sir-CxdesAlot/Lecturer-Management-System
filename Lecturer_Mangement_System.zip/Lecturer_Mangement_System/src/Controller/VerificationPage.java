package Controller;

import javafx.fxml.FXML;

public class VerificationPage {
    
    @FXML
    private void handleVerify() {
        Navigation.navigateTo("/View/VerificationConfirmed.fxml", "Verification Confirmed");
    }
}
