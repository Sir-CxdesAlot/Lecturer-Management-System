package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class VerificationConfirmed {

    @FXML
    public void handleBackToLogin() {

        Navigation.navigateTo("/View/LoginPage.fxml", "Login Page");
    }
    
}
