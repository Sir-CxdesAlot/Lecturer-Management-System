package Controller;


public class DeleteLecturer {
    
}
