package Controller;

import javafx.fxml.FXML;

public class UpdateLecturerInfo {

    @FXML
    private void handleUpdate() {
        Navigation.navigateTo("/View/UpdateConfirmation.fxml", "Faculty Lecturers");
    }
    
}
