package Controller;

import Data.FacultyLecturers2Data;
import Model.lectureCardModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class FacultyLecturers implements Initializable {

    @FXML
    private ScrollPane LecturerScrollP;

    private VBox cardContainer;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Create a VBox container for vertical layout
        cardContainer = new VBox();
        cardContainer.setSpacing(15); // Space between cards
        cardContainer.setStyle("-fx-padding: 10;"); // Add some padding around the container

        // Set the VBox as the content of the ScrollPane
        LecturerScrollP.setContent(cardContainer);

        // Load all lecturer cards
        loadLecturerCards();
    }

    private void loadLecturerCards() {
        try {
            // Loop through all the dummy data and create cards
            for (int i = 0; i < FacultyLecturers2Data.LECTURER_TITLES.length; i++) {
                // Create a new lecturer model with data
                lectureCardModel lecturer = new lectureCardModel(
                        FacultyLecturers2Data.LECTURER_TITLES[i],
                        FacultyLecturers2Data.LECTURER_OFFICES[i],
                        FacultyLecturers2Data.LECTURER_COURSES[i]
                );

                // Load the FXML for individual card
                FXMLLoader cardLoader = new FXMLLoader(getClass().getResource("/View/FacultyLecturers2.fxml"));

                // Load the card view
                javafx.scene.Node cardView = cardLoader.load();

                // Get the controller and set the data
                FacultyLecturers2 cardController = cardLoader.getController();
                cardController.setLecturer(lecturer);

                // Add the card to the VBox container (this makes them stack vertically)
                cardContainer.getChildren().add(cardView);
            }

            System.out.println("Successfully loaded " + FacultyLecturers2Data.LECTURER_TITLES.length + " lecturer cards");

        } catch (IOException e) {
            System.err.println("Error loading lecturer cards: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Button handler for "Add New Lecturer"
    @FXML
    private void handleAddLecturer(ActionEvent event) {
        // CALL navigateTo with the required title argument
        Navigation.navigateTo("/View/AddLecturerInfo.fxml", "Add Lecturer Info");
    }

    @FXML
    private void handleLogout(ActionEvent event) {

        Navigation.navigateTo("/View/LoginPage.fxml", "Login");
    }
}
