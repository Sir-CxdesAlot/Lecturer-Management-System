package Controller;
import Model.lectureCardModel;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class FacultyLecturers2 {

    @FXML
    private Label LecturerTitle;

    @FXML
    private Label LecturerOffice;

    @FXML
    private Label LecturerCourse;

    private lectureCardModel lecturerCard; 

    // Populate individual card with data
    public void setLecturer(lectureCardModel lecturerCard) {
        this.lecturerCard = lecturerCard;

        // Setting the cards properties using the model's getters
        LecturerTitle.setText(lecturerCard.getLecturerTitle());
        LecturerOffice.setText(lecturerCard.getLecturerOffice());
        LecturerCourse.setText(lecturerCard.getLecturerCourse());
    }

    @FXML
    private void handleEdit() {
        // Navigate to the Lecturer Details Page
        Navigation.navigateTo("/View/UpdateLecturerInfo.fxml", "Update Lecturer Info");
    }

    @FXML
    private void handleDelete() {
        // Logic to delete the lecturer can be added here
        Navigation.navigateTo("/View/DeletionConfirmation.fxml", "Deletion Confirmation");
    }
}