package Controller;

import javafx.fxml.FXML;

public class UpdateConfirmation {

    @FXML
    private void handleConfirmUpdate() {
        Navigation.navigateTo("/View/UpdateMessage.fxml", "Update Message");
    }
    
}
