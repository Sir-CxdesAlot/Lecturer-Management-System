package Data;

public class CourseCatalog2Data {

    //CourseName
    public static final String[] CourseTitle = {
       "Courses: CS101, CS202",
        "Mathematics",
        "Physics",
        "Chemistry", 
        "Biology",
        "Psychology",
        "Engineering",
        "English Literature",
        "History",
        "Economics"
    };


        //CourseName
    public static final String[] LecturerTitle = {
        "Dr. John Smith",
        "Prof. Sarah Johnson", 
        "Dr. Michael Brown",
        "Prof. Emily Davis",
        "Dr. David Wilson",
        "Prof. Lisa Garcia",
        "Dr. Robert Martinez",
        "Prof. Jennifer Lee",
        "Dr. William Taylor",
        "Prof. Amanda White"
    };


    public static final String[] CourseInfo = {
        "Courses: CS101, CS202",
        "Mathematics",
        "Physics",
        "Chemistry", 
        "Biology",
        "Psychology",
        "Engineering",
        "English Literature",
        "History",
        "Economics"
    };
}