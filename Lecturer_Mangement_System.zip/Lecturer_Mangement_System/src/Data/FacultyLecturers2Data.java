package Data;

public class FacultyLecturers2Data {
    
    // Lecturer Titles
    public static final String[] LECTURER_TITLES = {
        "Dr. John Smith",
        "Prof. Sarah Johnson", 
        "Dr. Michael Brown",
        "Prof. Emily Davis",
        "Dr. David Wilson",
        "Prof. Lisa Garcia",
        "Dr. Robert Martinez",
        "Prof. Jennifer Lee",
        "Dr. William Taylor",
        "Prof. Amanda White"
    };
    
    // Lecturer Offices
    public static final String[] LECTURER_OFFICES = {
        "LC001  |  Office: 405A, Science B",
        "Room 205B",
        "Room 303C", 
        "Room 150A",
        "Room 220B",
        "Room 180C",
        "Room 125A",
        "Room 275B",
        "Room 310C",
        "Room 195A"
    };
    
    // Lecturer Courses
    public static final String[] LECTURER_COURSES = {
        "Courses: CS101, CS202",
        "Mathematics",
        "Physics",
        "Chemistry", 
        "Biology",
        "Psychology",
        "Engineering",
        "English Literature",
        "History",
        "Economics"
    };
}