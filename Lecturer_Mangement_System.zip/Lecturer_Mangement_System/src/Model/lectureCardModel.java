package Model;

public class lectureCardModel {

    private String LecturerTitle;
    private String LecturerOffice;
    private String LecturerCourse;
    
    // Constructors
    public lectureCardModel() {
        // Default constructor
    }
    
    public lectureCardModel(String lecturerTitle, String lecturerOffice, String lecturerCourse) {
        this.LecturerTitle = lecturerTitle;
        this.LecturerOffice = lecturerOffice;
        this.LecturerCourse = lecturerCourse;
    }
    
    // Getters
    public String getLecturerTitle() {
        return LecturerTitle;
    }
    
    public String getLecturerOffice() {
        return LecturerOffice;
    }
    
    public String getLecturerCourse() {
        return LecturerCourse;
    }
    
    // Setters
    public void setLecturerTitle(String lecturerTitle) {
        this.LecturerTitle = lecturerTitle;
    }
    
    public void setLecturerOffice(String lecturerOffice) {
        this.LecturerOffice = lecturerOffice;
    }
    
    public void setLecturerCourse(String lecturerCourse) {
        this.LecturerCourse = lecturerCourse;
    }
    
}